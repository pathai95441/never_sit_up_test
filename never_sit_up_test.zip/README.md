# Hi, This my test for the NEVER SITUP Company


``` bash
# check nodejs in machine
$ node --version 
# if not have nodejs you can download from link
link: https://nodejs.org/en/download

# install dependencies
$ npm install

# run test
$ npm test

# run logic shuffling & we can insert input in command line
$ npm run shuffling
# example $ npm run shuffling abc

# run logic find_the_odd_int & we can insert input in command line
$ npm run find_the_odd_int
# example $ npm run find_the_odd_int [1,2,2,3,3,3,4,3,3,3,2,2,1]

# run logic count_the_smiley_faces & we can insert input in command line
$ npm run count_the_smiley_faces
# example $ npm run count_the_smiley_faces ";], :[, ;*, :$, ;-D"
```

FYI this script require run on nodejs version 16 or higher